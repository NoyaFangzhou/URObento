1. create.sql includes cmd create all tables in this project,
2. load.sql can automately load information from restaurant_new_info.dat and new_dish.dat to UROB_Restaurant and UROB_Dish table, it also includes command insert dump records into other tables;
3. new_dish.dat includes the dish info we caputured in yelp;
4. restaurant_new_info.dat includes restaurant info we caputured through yelp API. 